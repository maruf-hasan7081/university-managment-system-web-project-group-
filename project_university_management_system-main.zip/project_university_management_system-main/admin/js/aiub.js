function loadpage(page)
{
    document.getElementById("idframe").src = page;
}